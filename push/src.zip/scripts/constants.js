/* eslint-env browser */

window.gauntface = window.gauntface || {};
window.gauntface.CONSTANTS = {
  GCM_API_KEY: 'AIzaSyBBh4ddPa96rQQNxqiq_qQj7sq1JdsNQUQ',
  APPLICATION_KEYS: {
    publicKey: 'BDd3_hVL9fZi9Ybo2UUzA284WG5FZR30_95YeZJsiA' +
      'pwXKpNcF1rRPF3foIiBHXRdJI2Qhumhf6_LFTeZaNndIo',
    privateKey: 'xKZKYRNdFFn8iQIF2MH54KTfUHwH105zBdzMR7SI3xI',
  },
};
